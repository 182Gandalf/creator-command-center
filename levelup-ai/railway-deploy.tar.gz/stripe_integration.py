# Stripe Configuration - Uses environment variables
import os

STRIPE_PUBLISHABLE_KEY = os.environ.get('STRIPE_PUBLISHABLE_KEY', '')
STRIPE_SECRET_KEY = os.environ.get('STRIPE_SECRET_KEY', '')

SUBSCRIPTION_PLANS = {
    'free': {'name': 'Free', 'price': 0, 'features': {'platforms': 1, 'posts': 10}},
    'pro': {'name': 'Pro', 'price': 12, 'features': {'platforms': 'unlimited', 'posts': 'unlimited'}},
    'team': {'name': 'Team', 'price': 29, 'features': {'platforms': 'unlimited', 'posts': 'unlimited'}}
}
