#!/bin/bash
# Setup script for Creator Command Center

echo "Setting up Creator Command Center..."

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install requirements
pip install -r requirements.txt

# Set environment variables
export FLASK_APP=app.py
export FLASK_ENV=development
export YOUTUBE_API_KEY="AIzaSyA8LLamcApR0eoSr4AVv8aAwL85zZmJBoI"
export INSTAGRAM_APP_ID="855485897533077"
export INSTAGRAM_APP_SECRET="e24326c13dab3116f012465ae53b51b2"

# Initialize database
flask db init
flask db migrate -m "Initial migration"
flask db upgrade

echo "Setup complete!"
echo "Run: flask run"
